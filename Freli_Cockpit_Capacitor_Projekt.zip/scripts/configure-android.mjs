import fs from 'node:fs';
import path from 'node:path';

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  console.error('AndroidManifest.xml nicht gefunden:', manifestPath);
  process.exit(1);
}

let xml = fs.readFileSync(manifestPath, 'utf8');

// 1. largeHeap + requestLegacyExternalStorage am <application>-Tag ergänzen
if (!xml.includes('android:largeHeap=')) {
  xml = xml.replace('<application', '<application\n        android:largeHeap="true"');
}
if (!xml.includes('android:requestLegacyExternalStorage=')) {
  xml = xml.replace('<application', '<application\n        android:requestLegacyExternalStorage="true"');
}

// 2. Benötigte Berechtigungen für lokalen Speicher & Kamera ergänzen
const permissions = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />'
];

const missingPerms = permissions.filter((line) => {
  const match = line.match(/android:name="([^"]+)"/);
  return match && !xml.includes(match[1]);
});

if (missingPerms.length) {
  xml = xml.replace('</manifest>', `    ${missingPerms.join('\n    ')}\n</manifest>`);
}

// 3. <queries> für Google Maps, WhatsApp, Telefon & Kalender auf Android 11+
if (!xml.includes('<queries>')) {
  const queriesBlock = `    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.SENDTO" />
            <data android:scheme="mailto" />
        </intent>
    </queries>`;
  xml = xml.replace('<application', `${queriesBlock}\n\n    <application`);
}

fs.writeFileSync(manifestPath, xml, 'utf8');
console.log('✅ AndroidManifest.xml erfolgreich für FRELI Cockpit konfiguriert.');

// 4. App-Version sauber setzen
const gradlePath = path.resolve('android/app/build.gradle');
if (fs.existsSync(gradlePath)) {
  let gradle = fs.readFileSync(gradlePath, 'utf8');
  const pkg = JSON.parse(fs.readFileSync(path.resolve('package.json'), 'utf8'));
  const verName = pkg.version || '2.0.0';
  gradle = gradle.replace(/versionName\s+"[^"]+"/, `versionName "${verName}"`);
  fs.writeFileSync(gradlePath, gradle, 'utf8');
  console.log(`✅ Android versionName auf ${verName} gesetzt.`);
}
