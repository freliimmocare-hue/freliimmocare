# FRELI ImmoCare – Mobiles Baustellen-Cockpit (Android APK)

Dieses Capacitor-Projekt baut aus `www/index.html` eine vollwertige, 100 % werbefreie und offline-fähige **Android-APK** für dein Tablet – inklusive:

- **Direktem Speicherzugriff** auf `Dokumente/FRELI/` für alle PDFs, Excel-Tabellen (`.xlsx`) und JSON-Backups
- **Nativem Android-Teilen-Menü** (WhatsApp, E-Mail, Google Drive, PDF-Viewer)
- **Großem lokalem Speicher** (`IndexedDB` + stilles Auto-Backup im Gerätespeicher)
- **Android-Zurück-Taste** & **Auto-Entwurf** für offene Formulareingaben
- **FRELI-App-Icon & Startbildschirm** automatisch eingebunden

## Kostenlose APK in 3 Minuten über GitHub bauen (ohne Android Studio)

1. Kostenloses Konto auf **github.com** anlegen (oder einloggen).
2. Auf **New repository** klicken, Namen z. B. `freli-cockpit` vergeben und auf **Create repository** klicken.
3. Dieses ZIP entpacken und **alle enthaltenen Dateien und Ordner** (inkl. des versteckten Ordners `.github/`) in das Repository hochladen (am einfachsten per GitHub Desktop, git oder Datei-Upload).
4. Oben im Repository auf den Reiter **Actions** klicken → links **FRELI Cockpit Android APK bauen** wählen → auf **Run workflow** klicken.
5. Nach ca. 2–3 Minuten ist der grüne Haken da. Ganz unten auf der Seite unter **Artifacts** auf **`FRELI-Cockpit-Tablet-APK`** klicken und die ZIP herunterladen.
6. Entpacken → **`FRELI-Cockpit-Tablet.apk`** auf dein Tablet kopieren und antippen zum Installieren.

## Spätere App-Updates

Um die App später zu aktualisieren, ersetzt du einfach `www/index.html` im GitHub-Repository – GitHub baut automatisch sofort eine neue APK. (Vor der Installation einer neuen Version immer kurz **💾 Backup sichern** in der App drücken.)
